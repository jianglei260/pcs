package com.cuit.pcs.apkloader;

/**
 * Created by ASUS-1 on 2015/9/13.
 */
public class AppCompoment {
    protected String name;
    protected String classPath;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getClassPath() {
        return classPath;
    }

    public void setClassPath(String classPath) {
        this.classPath = classPath;
    }
}
