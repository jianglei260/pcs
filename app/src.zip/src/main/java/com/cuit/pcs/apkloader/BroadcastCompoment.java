package com.cuit.pcs.apkloader;

/**
 * Created by ASUS-1 on 2015/9/13.
 */
public class BroadcastCompoment extends AppCompoment {
    private String action;

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }
}
