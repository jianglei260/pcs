package com.cuit.pcs.apkloader;

/**
 * Created by ASUS-1 on 2015/9/13.
 */
public abstract class ServiceCompoment extends AppCompoment {
    public abstract void run(Runnable r);
}
