package com.cuit.pcs.sys.window;

import android.content.Context;

import com.cuit.pcs.application.MyApplication;

/**
 * Created by ASUS-1 on 2015/11/27.
 */
public class PlugWindowPage extends WindowPage {
    public PlugWindowPage(Context context) {
        super(MyApplication.getInstance().getMainActivity());
    }
}
