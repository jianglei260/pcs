package com.cuit.pcs.ui.view.main;

import android.support.v7.widget.RecyclerView;

/**
 * Created by ASUS-1 on 2015/9/15.
 */
public class MainLayoutManager extends RecyclerView.LayoutManager {
    @Override
    public RecyclerView.LayoutParams generateDefaultLayoutParams() {
        return null;
    }
}
