package library.widget;

public interface PoolObjectFactory<T> {
  T createObject();
}
